import React, { useEffect, useState } from 'react';
import './MyPage.css';

const MyPage = () => {
  const [userInfo, setUserInfo] = useState({
    name: '',
    userId: '',
    email: '',
    nickName: '',
  });

  useEffect(() => {
    const storedUserId = localStorage.getItem('userId');
    const storedEmail = localStorage.getItem('email');
    const storedNickName = localStorage.getItem('nickName');
    const storedName = localStorage.getItem('name'); // 저장한 적 없다면 백엔드 요청 필요

    setUserInfo({
      name: storedName || '이름 정보 없음',
      userId: storedUserId || '아이디 없음',
      email: storedEmail || '이메일 없음',
      nickName: storedNickName || '닉네임 없음',
    });
  }, []);

  return (
    <div className="mypage-container">
      <h2>마이페이지</h2>
      <div className="mypage-info">
        <p><strong>이름:</strong> {userInfo.name}</p>
        <p><strong>아이디:</strong> {userInfo.userId}</p>
        <p><strong>이메일:</strong> {userInfo.email}</p>
        <p><strong>닉네임:</strong> {userInfo.nickName}</p>
      </div>
    </div>
  );
};

export default MyPage;
