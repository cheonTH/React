import React, { useState } from 'react';
import './FindId.css';

const FindId = () => {
  const [email, setEmail] = useState('');

  const handleFindId = (e) => {
    e.preventDefault();
    console.log('입력한 이메일:', email);
    // TODO: 서버에 이메일 보내고 아이디 찾기 요청
  };

  return (
    <div className="find-container">
      <h2>아이디 찾기</h2>
      <form onSubmit={handleFindId} className="find-form">
        <input
          type="email"
          placeholder="가입한 이메일 입력"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <button type="submit">아이디 찾기</button>
      </form>
    </div>
  );
};

export default FindId;
