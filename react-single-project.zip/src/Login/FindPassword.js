import React, { useState } from 'react';
import './FindPassword.css';

const FindPassword = () => {
  const [userId, setUserId] = useState('');
  const [email, setEmail] = useState('');

  const handleFindPassword = (e) => {
    e.preventDefault();
    console.log('아이디:', userId, '이메일:', email);
    // TODO: 서버에 아이디와 이메일을 보내고 비밀번호 찾기 요청
  };

  return (
    <div className="find-container">
      <h2>비밀번호 찾기</h2>
      <form onSubmit={handleFindPassword} className="find-form">
        <input
          type="text"
          placeholder="아이디 입력"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          required
        />
        <input
          type="email"
          placeholder="가입한 이메일 입력"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <button type="submit">비밀번호 찾기</button>
      </form>
    </div>
  );
};

export default FindPassword;
