import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './BoardWrite.css';

const BoardWrite = ({ selectedMenu, setSelectedMenu }) => {
  const navigate = useNavigate();

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [file, setFile] = useState(null);

  const [category, setCategory] = useState('');


  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('제목:', title);
    console.log('내용:', content);
    console.log('첨부파일:', file);
  };

  const goToBoard = () => {
    navigate('/board');
    setSelectedMenu('/board');
  };

  return (
    <div className="board-write-container">
      <h2>게시글 작성</h2>
      <form onSubmit={handleSubmit} className="board-write-form">
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          required
        >
          <option value="">카테고리 선택</option>
          <option value="tip">자취 팁</option>
          <option value="자유">자유게시판</option>
          <option value="질문">자취 질문</option>
        </select>

        <input
          type="text"
          placeholder="제목을 입력하세요"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <textarea
          placeholder="내용을 입력하세요"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
        />
        <input
          type="file"
          onChange={(e) => setFile(e.target.files[0])}
        />
        <button type="submit">작성 완료</button>
      </form>

      <button className="home-button" onClick={goToBoard}>
        게시판으로 이동
      </button>
    </div>
  );
};

export default BoardWrite;
