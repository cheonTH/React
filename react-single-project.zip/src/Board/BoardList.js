import React from 'react';
import BoardItem from './BoardItem';
import { Link } from 'react-router-dom';
import './BoardList.css';
import dummyData from './boardDummy'; // 카테고리 포함된 더미 데이터

const BoardList = ({ selectedCategory }) => {
  const filteredData = selectedCategory === 'all'
    ? dummyData
    : dummyData.filter(item => item.category === selectedCategory);

  return (
    <div className="board-list-container">
      <h2 className="board-list-title">게시판</h2>
      <div className="board-list">
        {filteredData.map((item) => (
          <Link to={`/board/${item.id}`} key={item.id} className="link-item">
            <BoardItem
              category={item.category}
              title={item.title}
              content={item.author}
              createdDate={item.createdDate}
            />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default BoardList;
