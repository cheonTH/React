const dummyData = [
  {
    id: 1,
    title: '냉장고 정리 꿀팁',
    author: '자취러1',
    content: '정리할 땐 이렇게!',
    category: 'tip',
    createdDate: '2025.07.10',
  },
  {
    id: 2,
    title: '오늘 날씨 맑네요',
    author: '자유인',
    content: '산책하기 좋겠어요.',
    category: '자유',
    createdDate: '2025.07.10',
  },
  {
    id: 3,
    title: '세탁기 고장났는데 어떡하죠?',
    author: '자취초보',
    content: '도움 부탁드려요!',
    category: '질문',
    createdDate: '2025.07.09',
  },
  // 추가 데이터...
];

export default dummyData;
