import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import dummyData from './boardDummy';
import './BoardDetail.css';

const dummyComments = [
  { id: 1, author: '댓글러1', text: '좋은 정보 감사합니다!' },
  { id: 2, author: '댓글러2', text: '정말 유용했어요' },
  { id: 3, author: '댓글러3', text: '혼밥팁 최고네요' },
  { id: 4, author: '댓글러4', text: '공감됩니다' },
  { id: 5, author: '댓글러5', text: '이런 글 자주 부탁드려요' },
  { id: 6, author: '댓글러6', text: '도움됐어요!' },
];

const BoardDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const board = dummyData.find((item) => item.id === parseInt(id));
  const [comments, setComments] = useState(dummyComments);
  const [commentInput, setCommentInput] = useState('');
  const [showAllComments, setShowAllComments] = useState(false);
  const [likes, setLikes] = useState(0);

  if (!board) {
    return <div>❌ 게시글을 찾을 수 없습니다.</div>;
  }

  const handleCommentSubmit = () => {
    if (!commentInput.trim()) return;
    const newComment = {
      id: comments.length + 1,
      author: '익명', // 실제 사용자라면 로그인 정보로 대체
      text: commentInput,
    };
    setComments([newComment, ...comments]);
    setCommentInput('');
  };

  return (
    <div className="board-detail-container">
        <p className='board-category'>{board.category}</p>
        <h2 className="board-detail-title">{board.title}</h2>
        <div className="board-detail-meta">
            <span>👤 {board.author}</span>
            <span>🕒 {board.createdDate}</span>
        </div>
        <hr />

        <div className="board-detail-content">{board.content}</div>

        {/* 좋아요 버튼 */}
        <div className="like-section">
            ❤️ <button onClick={() => setLikes(likes + 1)}>좋아요</button> {likes}개
        </div>

        {/* 댓글 작성 */}
        <div className="comment-section">
            <h4>💬 댓글</h4>
            <textarea
            value={commentInput}
            onChange={(e) => setCommentInput(e.target.value)}
            placeholder="댓글을 입력하세요..."
            rows={3}
            />
            <button onClick={handleCommentSubmit}>작성</button>

            <ul className="comment-list">
            {(showAllComments ? comments : comments.slice(0, 5)).map((comment) => (
                <li key={comment.id}>
                <strong>{comment.author}</strong>: {comment.text}
                </li>
            ))}
            </ul>
            {comments.length > 5 && (
            <button onClick={() => setShowAllComments(!showAllComments)}>
                {showAllComments ? '접기' : '더보기'}
            </button>
            )}
        </div>

        {/* 하단 버튼 */}
        <div className="detail-footer">
            <div className="footer-left">
            <button onClick={() => navigate('/board')}>← 목록으로</button>
            </div>
            <div className="footer-right">
            <button onClick={() => navigate(`/board/${id}/edit`)}>✏️ 수정</button>
            <button onClick={() => alert('삭제 기능')}>🗑 삭제</button>
            </div>
        </div>
    </div>
  );
};

export default BoardDetail;
