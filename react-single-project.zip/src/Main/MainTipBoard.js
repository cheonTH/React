import React from 'react';
import './MainTipBoard.css';
import { Link } from 'react-router-dom';
import BoardItem from '../Board/BoardItem';
import dummyData from '../Board/boardDummy';

const MainTipBoard = () => {
  const tipPosts = dummyData
    .filter(item => item.category === 'tip')
    .slice(0, 3); // 최대 3개만

  return (
    <div className="main-tip-board-container">
      <h2>💡 혼자 살 때 꿀팁</h2>
      <div className="main-tip-board-list">
        {tipPosts.map((item) => (
          <Link to={`/board/${item.id}`} key={item.id} className="tip-link-item">
            <BoardItem
              category={item.category}
              title={item.title}
              content={item.author}
              createdDate={item.createdDate}
            />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default MainTipBoard;
